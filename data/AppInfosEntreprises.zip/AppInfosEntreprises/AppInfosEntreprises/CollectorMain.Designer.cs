﻿namespace AppInfosEntreprises
{
    partial class FenetreMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FenetreMain));
            this.lblNameEnterprise = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.textNameEnterprise = new System.Windows.Forms.TextBox();
            this.textDescription = new System.Windows.Forms.TextBox();
            this.lblDateFondation = new System.Windows.Forms.Label();
            this.dateDateFondation = new System.Windows.Forms.DateTimePicker();
            this.lblNumMembers = new System.Windows.Forms.Label();
            this.numNumMembers = new System.Windows.Forms.NumericUpDown();
            this.lblActionValues = new System.Windows.Forms.Label();
            this.numActionValue = new System.Windows.Forms.NumericUpDown();
            this.dateActionValue = new System.Windows.Forms.DateTimePicker();
            this.lblDateActionValue = new System.Windows.Forms.Label();
            this.lblListLastGames = new System.Windows.Forms.Label();
            this.textListLastGames = new System.Windows.Forms.TextBox();
            this.textListNextGames = new System.Windows.Forms.TextBox();
            this.lblListNextGames = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fichierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enregistrerSousToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ouvrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.fermerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            ((System.ComponentModel.ISupportInitialize)(this.numNumMembers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numActionValue)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNameEnterprise
            // 
            this.lblNameEnterprise.AutoSize = true;
            this.lblNameEnterprise.Location = new System.Drawing.Point(8, 29);
            this.lblNameEnterprise.Name = "lblNameEnterprise";
            this.lblNameEnterprise.Size = new System.Drawing.Size(155, 19);
            this.lblNameEnterprise.TabIndex = 0;
            this.lblNameEnterprise.Text = "Nom de l\'entreprise :";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(8, 83);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(168, 19);
            this.lblDescription.TabIndex = 1;
            this.lblDescription.Text = "Description (Résumé) :";
            // 
            // textNameEnterprise
            // 
            this.textNameEnterprise.Location = new System.Drawing.Point(12, 54);
            this.textNameEnterprise.Name = "textNameEnterprise";
            this.textNameEnterprise.Size = new System.Drawing.Size(462, 26);
            this.textNameEnterprise.TabIndex = 2;
            // 
            // textDescription
            // 
            this.textDescription.Location = new System.Drawing.Point(12, 105);
            this.textDescription.Multiline = true;
            this.textDescription.Name = "textDescription";
            this.textDescription.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textDescription.Size = new System.Drawing.Size(462, 104);
            this.textDescription.TabIndex = 3;
            // 
            // lblDateFondation
            // 
            this.lblDateFondation.AutoSize = true;
            this.lblDateFondation.Location = new System.Drawing.Point(8, 212);
            this.lblDateFondation.Name = "lblDateFondation";
            this.lblDateFondation.Size = new System.Drawing.Size(141, 19);
            this.lblDateFondation.TabIndex = 4;
            this.lblDateFondation.Text = "Date de fondation :";
            // 
            // dateDateFondation
            // 
            this.dateDateFondation.Location = new System.Drawing.Point(12, 235);
            this.dateDateFondation.Name = "dateDateFondation";
            this.dateDateFondation.Size = new System.Drawing.Size(200, 26);
            this.dateDateFondation.TabIndex = 5;
            // 
            // lblNumMembers
            // 
            this.lblNumMembers.AutoSize = true;
            this.lblNumMembers.Location = new System.Drawing.Point(8, 264);
            this.lblNumMembers.Name = "lblNumMembers";
            this.lblNumMembers.Size = new System.Drawing.Size(164, 19);
            this.lblNumMembers.TabIndex = 6;
            this.lblNumMembers.Text = "Nombre de membres :";
            // 
            // numNumMembers
            // 
            this.numNumMembers.Location = new System.Drawing.Point(12, 287);
            this.numNumMembers.Name = "numNumMembers";
            this.numNumMembers.Size = new System.Drawing.Size(151, 26);
            this.numNumMembers.TabIndex = 7;
            // 
            // lblActionValues
            // 
            this.lblActionValues.AutoSize = true;
            this.lblActionValues.Location = new System.Drawing.Point(8, 316);
            this.lblActionValues.Name = "lblActionValues";
            this.lblActionValues.Size = new System.Drawing.Size(166, 19);
            this.lblActionValues.TabIndex = 8;
            this.lblActionValues.Text = "Action (Valeur/Unité) :";
            // 
            // numActionValue
            // 
            this.numActionValue.Location = new System.Drawing.Point(12, 338);
            this.numActionValue.Name = "numActionValue";
            this.numActionValue.Size = new System.Drawing.Size(151, 26);
            this.numActionValue.TabIndex = 9;
            // 
            // dateActionValue
            // 
            this.dateActionValue.Location = new System.Drawing.Point(192, 338);
            this.dateActionValue.Name = "dateActionValue";
            this.dateActionValue.Size = new System.Drawing.Size(236, 26);
            this.dateActionValue.TabIndex = 10;
            // 
            // lblDateActionValue
            // 
            this.lblDateActionValue.AutoSize = true;
            this.lblDateActionValue.Location = new System.Drawing.Point(188, 316);
            this.lblDateActionValue.Name = "lblDateActionValue";
            this.lblDateActionValue.Size = new System.Drawing.Size(240, 19);
            this.lblDateActionValue.TabIndex = 11;
            this.lblDateActionValue.Text = "Date de la prise de l\'information :";
            // 
            // lblListLastGames
            // 
            this.lblListLastGames.AutoSize = true;
            this.lblListLastGames.Location = new System.Drawing.Point(8, 367);
            this.lblListLastGames.Name = "lblListLastGames";
            this.lblListLastGames.Size = new System.Drawing.Size(284, 38);
            this.lblListLastGames.TabIndex = 12;
            this.lblListLastGames.Text = "Liste des derniers jeux :\r\n*Passer une ligne entre chacun des jeux";
            // 
            // textListLastGames
            // 
            this.textListLastGames.Location = new System.Drawing.Point(12, 408);
            this.textListLastGames.Multiline = true;
            this.textListLastGames.Name = "textListLastGames";
            this.textListLastGames.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textListLastGames.Size = new System.Drawing.Size(462, 104);
            this.textListLastGames.TabIndex = 13;
            // 
            // textListNextGames
            // 
            this.textListNextGames.Location = new System.Drawing.Point(12, 556);
            this.textListNextGames.Multiline = true;
            this.textListNextGames.Name = "textListNextGames";
            this.textListNextGames.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textListNextGames.Size = new System.Drawing.Size(462, 104);
            this.textListNextGames.TabIndex = 15;
            // 
            // lblListNextGames
            // 
            this.lblListNextGames.AutoSize = true;
            this.lblListNextGames.Location = new System.Drawing.Point(8, 515);
            this.lblListNextGames.Name = "lblListNextGames";
            this.lblListNextGames.Size = new System.Drawing.Size(284, 38);
            this.lblListNextGames.TabIndex = 14;
            this.lblListNextGames.Text = "Liste des jeux à venir :\r\n*Passer une ligne entre chacun des jeux";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fichierToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(484, 24);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fichierToolStripMenuItem
            // 
            this.fichierToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ouvrirToolStripMenuItem,
            this.toolStripSeparator1,
            this.enregistrerSousToolStripMenuItem,
            this.toolStripSeparator2,
            this.fermerToolStripMenuItem});
            this.fichierToolStripMenuItem.Name = "fichierToolStripMenuItem";
            this.fichierToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.fichierToolStripMenuItem.Text = "Fichier";
            // 
            // enregistrerSousToolStripMenuItem
            // 
            this.enregistrerSousToolStripMenuItem.Name = "enregistrerSousToolStripMenuItem";
            this.enregistrerSousToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.enregistrerSousToolStripMenuItem.Text = "Enregistrer sous...";
            this.enregistrerSousToolStripMenuItem.Click += new System.EventHandler(this.SaveAs);
            // 
            // ouvrirToolStripMenuItem
            // 
            this.ouvrirToolStripMenuItem.Name = "ouvrirToolStripMenuItem";
            this.ouvrirToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.ouvrirToolStripMenuItem.Text = "Ouvrir";
            this.ouvrirToolStripMenuItem.Click += new System.EventHandler(this.OpenFile);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(163, 6);
            // 
            // fermerToolStripMenuItem
            // 
            this.fermerToolStripMenuItem.Name = "fermerToolStripMenuItem";
            this.fermerToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.fermerToolStripMenuItem.Text = "Fermer";
            this.fermerToolStripMenuItem.Click += new System.EventHandler(this.Close);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(163, 6);
            // 
            // FenetreMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(484, 667);
            this.Controls.Add(this.textListNextGames);
            this.Controls.Add(this.lblListNextGames);
            this.Controls.Add(this.textListLastGames);
            this.Controls.Add(this.lblListLastGames);
            this.Controls.Add(this.lblDateActionValue);
            this.Controls.Add(this.dateActionValue);
            this.Controls.Add(this.numActionValue);
            this.Controls.Add(this.lblActionValues);
            this.Controls.Add(this.numNumMembers);
            this.Controls.Add(this.lblNumMembers);
            this.Controls.Add(this.dateDateFondation);
            this.Controls.Add(this.lblDateFondation);
            this.Controls.Add(this.textDescription);
            this.Controls.Add(this.textNameEnterprise);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblNameEnterprise);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Cambria", 12F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FenetreMain";
            this.Text = "Trilux -Collecteur d\'Entreprises";
            ((System.ComponentModel.ISupportInitialize)(this.numNumMembers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numActionValue)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNameEnterprise;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox textNameEnterprise;
        private System.Windows.Forms.TextBox textDescription;
        private System.Windows.Forms.Label lblDateFondation;
        private System.Windows.Forms.DateTimePicker dateDateFondation;
        private System.Windows.Forms.Label lblNumMembers;
        private System.Windows.Forms.NumericUpDown numNumMembers;
        private System.Windows.Forms.Label lblActionValues;
        private System.Windows.Forms.NumericUpDown numActionValue;
        private System.Windows.Forms.DateTimePicker dateActionValue;
        private System.Windows.Forms.Label lblDateActionValue;
        private System.Windows.Forms.Label lblListLastGames;
        private System.Windows.Forms.TextBox textListLastGames;
        private System.Windows.Forms.TextBox textListNextGames;
        private System.Windows.Forms.Label lblListNextGames;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fichierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enregistrerSousToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ouvrirToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem fermerToolStripMenuItem;
    }
}

