﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppInfosEntreprises
{
    public partial class FenetreMain : Form
    {
        const string SEPARATOR = "#";
        const int NB_INFOS = 8;
        public FenetreMain()
        {
            InitializeComponent();
        }

        private void SaveAs(object sender, EventArgs e)
        {
            SaveFileDialog dialogSaveAs = new SaveFileDialog();
            dialogSaveAs.Filter = ".txt|Fichier Texte";
            dialogSaveAs.FileName = textNameEnterprise.Text;
            if (dialogSaveAs.ShowDialog() == DialogResult.OK)
            {
                StringBuilder builder = new StringBuilder();

                builder.AppendLine(SEPARATOR);
                builder.AppendLine(textNameEnterprise.Text);
                builder.AppendLine(SEPARATOR);
                builder.AppendLine(textDescription.Text);
                builder.AppendLine(SEPARATOR);
                builder.AppendLine(dateDateFondation.Text);
                builder.AppendLine(SEPARATOR);
                builder.AppendLine(numNumMembers.Value.ToString());
                builder.AppendLine(SEPARATOR);
                builder.AppendLine(numActionValue.Value.ToString());
                builder.AppendLine(SEPARATOR);
                builder.AppendLine(dateActionValue.Text);
                builder.AppendLine(SEPARATOR);
                builder.AppendLine(textListLastGames.Text);
                builder.AppendLine(SEPARATOR);
                builder.AppendLine(textListNextGames.Text);
                builder.AppendLine(SEPARATOR);

                System.IO.File.WriteAllText(dialogSaveAs.FileName + ".txt", builder.ToString());
            }
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog dialogOpen = new OpenFileDialog();
            dialogOpen.Filter = "Text Files (.txt)|*.txt|All Files (*.*)|*.*";
            if (dialogOpen.ShowDialog() == DialogResult.OK)
            {
                textNameEnterprise.Text = "";
                textDescription.Text = "";
                textListLastGames.Text = "";
                textListNextGames.Text = "";
                numNumMembers.Value = 0;
                numActionValue.Value = 0;
                List<string> results = new List<string>();
                int counter = 0;
                foreach (string line in System.IO.File.ReadAllLines(dialogOpen.FileName))
                {
                    if (line == SEPARATOR)
                    {
                        counter++;
                    }
                    else
                    {
                        switch (counter)
                        {
                            case 1:
                                textNameEnterprise.Text = line;
                                break;
                            case 2:
                                textDescription.Text = line;
                                break;
                            case 3:
                                dateDateFondation.Text = line;
                                break;
                            case 4:
                                numNumMembers.Value = int.Parse(line);
                                break;
                            case 5:
                                numActionValue.Value = int.Parse(line);
                                break;
                            case 6:
                                dateActionValue.Text = line;
                                break;
                            case 7:
                                textListLastGames.Text += line;
                                break;
                            case 8:
                                textListNextGames.Text += line;
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }

        private void Close(object sender, EventArgs e)
        {
            Close();
        }
    }
}
